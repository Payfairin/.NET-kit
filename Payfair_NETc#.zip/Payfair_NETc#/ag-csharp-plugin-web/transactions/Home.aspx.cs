﻿using System;
using Encryption.AES;
using System.Collections.Specialized;
using System.Collections.Generic;
using System.Linq;

public partial class Home : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       

   }

    protected void btns_Click(object sender, EventArgs e)
    {
        string paymentURL = (!String.IsNullOrEmpty(integrationtype.Value)) ? integrationtype.Value : string.Empty;
        string apikey = (!String.IsNullOrEmpty(api_key.Value)) ? api_key.Value : string.Empty;
        string secretsalt = (!String.IsNullOrEmpty(salt.Value)) ? salt.Value : string.Empty;
        string returnurl = (!String.IsNullOrEmpty(return_url.Value)) ? return_url.Value : string.Empty;
        string return_urlsuccess = (!String.IsNullOrEmpty(return_url_success.Value)) ? return_url_success.Value : string.Empty;
        string return_urlfailure = (!String.IsNullOrEmpty(return_url_failure.Value)) ? amount.Value : string.Empty;
        string modeenv = (!String.IsNullOrEmpty(mode.Value)) ? mode.Value : string.Empty;
        string order_no = (!String.IsNullOrEmpty(order_id.Value)) ? order_id.Value : string.Empty;
        string cost = (!String.IsNullOrEmpty(amount.Value)) ? amount.Value : string.Empty;
        string curr = (!String.IsNullOrEmpty(currency.Value)) ? currency.Value : string.Empty;
        string desc = (!String.IsNullOrEmpty(description.Value)) ? description.Value : string.Empty;
        string custname = (!String.IsNullOrEmpty(name.Value)) ? name.Value : string.Empty;
        string custemail = (!String.IsNullOrEmpty(email.Value)) ? email.Value : string.Empty;
        string custphone = (!String.IsNullOrEmpty(phone.Value)) ? phone.Value : string.Empty;
        string custaddress1 = (!String.IsNullOrEmpty(address1.Value)) ? address1.Value : string.Empty;
        string custaddress2 = (!String.IsNullOrEmpty(address2.Value)) ? address2.Value : string.Empty;
        string custcity = (!String.IsNullOrEmpty(city.Value)) ? city.Value : string.Empty;
        string custstate = (!String.IsNullOrEmpty(state.Value)) ? state.Value : string.Empty;
        string custzipcode = (!String.IsNullOrEmpty(zip_code.Value)) ? zip_code.Value : string.Empty;
        string custcountry = (!String.IsNullOrEmpty(country.Value)) ? country.Value : string.Empty;
        string udf_1 = (!String.IsNullOrEmpty(udf1.Value)) ? udf1.Value : string.Empty;
        string udf_2 = (!String.IsNullOrEmpty(udf2.Value)) ? udf2.Value : string.Empty;
        string udf_3 = (!String.IsNullOrEmpty(udf3.Value)) ? udf3.Value : string.Empty;
        string udf_4 = (!String.IsNullOrEmpty(udf4.Value)) ? udf4.Value : string.Empty;
        string udf_5 = (!String.IsNullOrEmpty(udf5.Value)) ? udf5.Value : string.Empty;
        string bankcode = (!String.IsNullOrEmpty(bank_code.Value)) ? bank_code.Value : string.Empty;
        string splitinfo = (!String.IsNullOrEmpty(split_info.Value)) ? split_info.Value : string.Empty;
        string splitenforcestrict = (!String.IsNullOrEmpty(split_enforce_strict.Value)) ? split_enforce_strict.Value : string.Empty;
        string percenttdrbyuser = (!String.IsNullOrEmpty(percent_tdr_by_user.Value)) ? percent_tdr_by_user.Value : string.Empty;
        string showconveniencefee = (!String.IsNullOrEmpty(show_convenience_fee.Value)) ? show_convenience_fee.Value : string.Empty;
        string paymentoptions = (!String.IsNullOrEmpty(payment_options.Value)) ? payment_options.Value : string.Empty;
        string allowedbankcodes = (!String.IsNullOrEmpty(allowed_bank_codes.Value)) ? allowed_bank_codes.Value : string.Empty;
        string allowedbins = (!String.IsNullOrEmpty(allowed_bins.Value)) ? allowed_bins.Value : string.Empty;
        string offercode = (!String.IsNullOrEmpty(offer_code.Value)) ? offer_code.Value : string.Empty;
        string allowedemitenure = (!String.IsNullOrEmpty(allowed_emi_tenure.Value)) ? allowed_emi_tenure.Value : string.Empty;
        string timeoutduration = (!String.IsNullOrEmpty(timeout_duration.Value)) ? timeout_duration.Value : string.Empty;
        string productdetails = (!String.IsNullOrEmpty(product_details.Value)) ? product_details.Value : string.Empty;
        string paymentpagedisplaytext = (!String.IsNullOrEmpty(payment_page_display_text.Value)) ? payment_page_display_text.Value : string.Empty;




        var value = new SortedDictionary<string, string>();
        value.Add("api_key", apikey);
        value.Add("return_url", returnurl);
        value.Add("return_url_success", return_urlsuccess);
        value.Add("return_url_failure", return_urlfailure);
        value.Add("mode", modeenv);
        value.Add("order_id", order_no);
        value.Add("amount", cost);
        value.Add("currency", curr);
        value.Add("description", desc);
        value.Add("name", custname);
        value.Add("email", custemail);
        value.Add("phone", custphone);
        value.Add("address1", custaddress1);
        value.Add("address2", custaddress2);
        value.Add("city", custcity);
        value.Add("state", custstate);
        value.Add("zip_code", custzipcode);
        value.Add("country", custcountry);
        value.Add("udf1", udf_1);
        value.Add("udf2", udf_2);
        value.Add("udf3", udf_3);
        value.Add("udf4", udf_4);
        value.Add("udf5", udf_5);
        value.Add("bank_code", bankcode);
        value.Add("split_info", splitinfo);
        value.Add("split_enforce_strict", splitenforcestrict);
        value.Add("percent_tdr_by_user", percenttdrbyuser);
        value.Add("show_convenience_fee", showconveniencefee);
        value.Add("payment_options", paymentoptions);
        value.Add("allowed_bank_codes", allowedbankcodes);
        value.Add("allowed_bins", allowedbins);
        value.Add("offer_code", offercode);
        value.Add("allowed_emi_tenure", allowedemitenure);
        value.Add("timeout_duration", timeoutduration);
        value.Add("product_details", productdetails);
        value.Add("payment_page_display_text", paymentpagedisplaytext);
        

      

        string data = secretsalt;
        string hash = "";
        MyCryptoClass aes = new MyCryptoClass();

        foreach (var item in value)
        {
            if(item.Value.Length > 0) { 
            data += "|" + item.Value.Trim();
            hash = aes.Generatehash512(data);
            }
        }

  

        NameValueCollection request = new NameValueCollection();
        request.Add("api_key", apikey);
        request.Add("return_url", returnurl);
        request.Add("return_url_success", return_urlsuccess);
        request.Add("return_url_failure", return_urlfailure);
        request.Add("mode", modeenv);
        request.Add("order_id", order_no);
        request.Add("amount", cost);
        request.Add("currency", curr);
        request.Add("description", desc);
        request.Add("name", custname);
        request.Add("email", custemail);
        request.Add("phone", custphone);
        request.Add("address1", custaddress1);
        request.Add("address2", custaddress2);
        request.Add("city", custcity);
        request.Add("state", custstate);
        request.Add("zip_code", custzipcode);
        request.Add("country", custcountry);
        request.Add("udf1", udf_1);
        request.Add("udf2", udf_2);
        request.Add("udf3", udf_3);
        request.Add("udf4", udf_4);
        request.Add("udf5", udf_5);
        request.Add("bank_code", bankcode);
        request.Add("split_info", splitinfo);
        request.Add("split_enforce_strict", splitenforcestrict);
        request.Add("percent_tdr_by_user", percenttdrbyuser);
        request.Add("show_convenience_fee", showconveniencefee);
        request.Add("payment_options", paymentoptions);
        request.Add("allowed_bank_codes", allowedbankcodes);
        request.Add("allowed_bins", allowedbins);
        request.Add("offer_code", offercode);
        request.Add("allowed_emi_tenure", allowedemitenure);
        request.Add("timeout_duration", timeoutduration);
        request.Add("product_details", productdetails);
        request.Add("payment_page_display_text", paymentpagedisplaytext);
        request.Add("hash", hash);

        HttpHelper.RedirectAndPOST(this.Page, paymentURL, request);
    }
}